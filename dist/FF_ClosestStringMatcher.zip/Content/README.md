Place the FF directory in your content directory.
